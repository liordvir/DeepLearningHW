r"""
Use this module to write your answers to the questions in the notebook.

Note: Inside the answer strings you can use Markdown format and also LaTeX
math (delimited with $$).
"""

# ==============
# Part 1 answers

part1_q1 = r"""
**Your answer:**

**1. False**.
 
 The in-sample error is defined across the train-data samples, and is defined as an average point-wise loss in the following fashion:

$L_{in}(h)=\frac{1}{N}\sum_{i=1}^{N}\ell(h(x_{i}),y_{i})$ Where $h(x_{i}),y_{i})$ are training sets.

On the other hand, the test-data samples gives us a notion of the out-sample error, and does not reflect necessarily the in-sample error.

**2. False**.
 
 To get effective results when training a model, we would like a sufficient number of data that is allocated in favor of the training set. 

As taught in lecture 2, it holds that the larger the training set size (N) grows, the more probable that the generalization gap will shrink:

$P(\left|L_{in}(h)-L_{out}(h)\right|>\epsilon)\leq2e^{-2\epsilon^{2}N}$

Therefore a split of data that will have a low amount of training data-size will probably not be sufficient for minimizing the generalization gap.

**3. True**.
 
The cross-validation process is done on the validation set which is allocated before training and is part of the train dataset.
Moreover it is intended to give us a notion of the performance of the selected model.
The test data should not be used while training and should not affect training at all, therefore this statement is true. 

**4. True**.
 
As explained in 3., The cross-validation set is intended to give us a notion of the performance of the selected model by approximating
the estimation error (which translates to the generalization gap). The estimation error approx. is calculated by:

$\varepsilon_{error}=L_{V}(h_{\mathcal{H},N}^{*})-L_{T}(h_{\mathcal{H},N}^{*})$

Where $L_{V}$ is the loss term for the model on the validation set. Therefore this statement is true.

"""

part1_q2 = r"""
Our friend is right.

$\lambda$ is a hyper-parameter that is used as a weight given to a regularization term which represents how much we 
would like our model to optimize the estimator with respect to $\left\Vert \vec{w}\right\Vert ^{w}$, and therefore 
avoid over-fitting in such cases. Our friend does right when he runs the model multiple times with different values 
of $\lambda$ since as we said this is a hyper parameter which should be learnt on a specific training session, 
and thus requires multiple runs. """

# ==============
# Part 2 answers

part2_q1 = r"""

Using a larger K value might prove useful in generalizing better for unseen data, however this is a problem-specific, 
and as with each case we would like to test this for different k values. There is no absolute k for each case, 
and therefore upon completion of cross-validation we select the model with k-value which had the best performance. 

When using a small k value, each neighbor has a bigger influence on label determination since we have less neighbors 
to consider. This eliminates situations where adding more neighbors might harm the labeling by pooling far-away 
neighbors which don't correlate with the same label. 

On the hand when k grows large, each neighbor has less weight on decision, thus more neighbors are used in selection 
and we might be able to handle a more general case for some samples, and mitigate miss-classification of 
abnormalities which in a smaller k be labeled as something false. """

part2_q2 = r"""
**Your answer:**

1. Using K-fold CV rather than selecting the best model with respect to train-set accuracy is preferable since using 
the validation set in K-fold gives us a notion of the estimation-error for unseen data, therefore relying only on the 
train-data and selecting the best performance upon it might result in a model which is over-fitting the training 
data, and does not generalize well on unseen data. 


2. Using k-fold CV divides the training set into k-folds, and each iteration a different fold serves as a validation 
dataset. Therefore in this process we cycle through the whole test dataset in different granularity, rather than 
running on the same test dataset. Moreover, a test set would be reserved only for giving a notion of the 
generalization error at the end of the training, and should not be part of the training. Using it in CV or in the 
training itself may contaminate the training process, and will not give a valid generalization error at the end of 
the training. 

"""

# ==============

# ==============
# Part 3 answers

part3_q1 = r"""**Your answer:** The $\Delta$ parameter defines how much of a margin we would like for a correct class 
prediction over the others.

The full loss is also defined by the regularization term, 
and therefore the ratios between $\lambda$ and $\Delta$ may define to what term we would like to optimize more. Therefore 
the $\Delta$ is arbitrary and we may also tune $\lambda$ to compensate whichever value $\Delta$ holds. 

"""

part3_q2 = r"""1. We can learn from the weight images what images will be classified. In the visualization provided 
for the weights, we can interpret what kind of template will be considered as a specific class, thus we can assume 
the model is trying to create a template image based on digits examples, and tries to create the most general form of 
a digit. We can also assume that in classification cases, the image ground truth label did not match enough the 
weight image for that label. We can also assume that the more blurry the weight image, the more complicated it will 
be for the model to give a precise prediction, such in digits 4 & 9 which are classified as one another sometimes.

 
 2. Similarities: Both linear classifier and KNN classifier are models that need to be trained before some valid predictions
 are given and based on examples (I.e datasets).
 We can also think of the 2D representation of these classifiers whereas the linear classifier creates hyper-planes that
 differentiate between samples, where these hyper planes are represented as straight lines, and the KNN creates more of "blobby"
 regions that are defined by the amount of neighbors.
 
 Differences: in KNN we define the loss as the l2 distance from other samples, whereas in the Linear Classifier we leverage
 the spacial features of images and create a model that tries to learn these features. (By using weights in linear classifier)
 
 Moreover, in KNN we store and memorize all samples rather then creating an epoch-based approach of training sessions in
 the linear classifier. 
 
 """

part3_q3 = r"""**Your answer:** 1. We think that our learning rate is well-defined since as we can see in the 
training graphs, we achieve convergence into a quite high accuracy (~90%) with no fluctuations. If we would have 
selected a smaller learning rate, we would expect the see that the loss is still descending and not converging, 
and if we would have selected a larger learning rate, we would expect to see fluctuations in the losses, 
what we don't see here. 

2. We think that our model is slightly overfitted on the training set since as we can see, the loss and accuracy of
the training set performs slightly better than the validations set, therefore the model is a bit biased towards the training
set.

"""

# ==============

# ==============
# Part 4 answers

part4_q1 = r"""
**Your answer:**
The ideal pattern to see in the residual plot is a constant line y=0, and that most of train and test data are centered 
around it with small variance of the data points.

From inspecting the top-5 classes residual plot, we can see that mse5 is much higher than the MSE of the cross-validated
model, and that the r2 score of CV is much closer to 1 (which is the best score in l2 means), therefore we can surmise that
using a CV approach might lead to better results.

By comparing the graphs, there is a considerable improvement of data centered around the zero line, as we can see less points
deviating from the standard deviation lines, and more centered. 

"""

part4_q2 = r"""
**Your answer:**

1. The model applying non-linearties is still linear in functions of X, meaning we are still linear with respect to weights,
 and therfore we can still consider it as a linear model, as we implement linear regression.
 
2. When knowing some relation between features in the X data, using a non-linear functions to augment them might 
improve fittness. (E.g if two feature behave like a function of one over the other [1/x] , we might want to inverse 
all the data to receive a linear relation).
However any function will eventually fit, but it will not necessarily improve the fitness of the whole model. 

3. Adding non-linear functions to the data will create decision boundaries that are not linear regarding the original data
and therefore we can not consider it a hyperplane any more (W.R.T to the original data).
However we can still consider this model to behave as hyper-planes W.R.T the transformation functions.

"""

part4_q3 = r"""
**Your answer:**

1. Using logspace gives a wider range of values that are different in scale.
Using different orders of magnitudes of lambda is necessary since we are interested in the effect of smaller ratios between
hyper-parameters.
Using a linear space we would miss most of the smaller scales, and would test the same magnitudes of ratio, and the search
will be less effective.

2. Given the data in the notebook:

$Deg \in {1,2,3}$

$\lambda \in \Lambda={10^{-3} ... 10^2}$

Such that $|\Lambda|=20$
And k_folds = 3

Therefore we have a grid search of $|Degrees|\times|\Lambda|$ = 60 cells
And each combination of this grid will be fitted k_fold times.
So we get $60\times3=180$ that the model was fitted.

In general the number of times that the model will be fitted is $|Degrees|\times|\Lambda|\times k fold$

"""

# ==============
